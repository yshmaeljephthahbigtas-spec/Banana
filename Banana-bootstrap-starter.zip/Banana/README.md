# Banana

A very simple Bootstrap 5 starter website.

## Main files

- `index.html` — edit your website text and sections here
- `css/style.css` — edit colors, fonts, spacing, and design here
- `js/script.js` — add JavaScript features here
- `images/` — place your images here

## Easiest way to update the website

Open `index.html` and look for comments like:

```html
<!-- EDIT WEBSITE NAME HERE -->
```

or:

```html
<!-- ABOUT SECTION -->
```

Replace the text under those comments.

## Add an image

1. Put your image inside the `images` folder.
2. Add this to `index.html`:

```html
<img src="images/your-image.jpg" class="img-fluid" alt="Description">
```

## Add a Bootstrap button

```html
<a href="#" class="btn btn-primary">Button Name</a>
```

## Add a new section

Copy this into `index.html` above the footer:

```html
<section class="py-5">
  <div class="container">
    <h2>Section Title</h2>
    <p>Your content here.</p>
  </div>
</section>
```

## GitHub Pages

After uploading this project to GitHub:

1. Open the repository.
2. Go to **Settings**.
3. Open **Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose `main` and `/root`.
6. Save.

Your site will then be published through GitHub Pages.

## Updating later with ChatGPT

You can simply say things like:

- "In Banana, add a login page."
- "In Banana, change the colors to blue."
- "In Banana, add a products section."
- "In Banana, add a contact form."

This project is intentionally kept simple so it is easy to expand.
